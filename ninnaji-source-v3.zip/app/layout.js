import './globals.css';

export const metadata = {
  title: '仁和寺 雲海ライトアップ 運営チェックリスト',
};

export default function RootLayout({ children }) {
  return (
    <html lang="ja">
      <body>{children}</body>
    </html>
  );
}
